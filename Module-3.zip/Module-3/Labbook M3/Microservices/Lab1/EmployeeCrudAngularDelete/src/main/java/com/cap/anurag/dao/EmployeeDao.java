package com.cap.anurag.dao;

public interface EmployeeDao {

	void deleteEmployeeById(Integer id);


}
