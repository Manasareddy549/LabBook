import java.util.Scanner;
public class Exercise1 {
	static int sumOfCubes( int n)
	{
		return 0;
	    
	}
	
    public static void main(String[] args) {
        System.out.println("�nter the Number");
        Scanner sc = new Scanner(System.in);
        int number = sc.nextInt();
        int sum=0;
		for(;number!=0; number = number / 10)
        {
        	int digit=number %10;
           sum=sum+digit*digit*digit;
          
        }

            System.out.println(sum);
     
    }
}








