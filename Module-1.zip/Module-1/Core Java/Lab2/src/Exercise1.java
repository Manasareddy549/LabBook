
abstract public class Exercise1 {
	private int identificationNumber;
	private String title;
	private int numberOfCopies;
	
	public int getUniqueIdentificationNumber() {
		return identificationNumber;
	}


	public void setUniqueIdentificationNumber(int uniqueIdentificationNumber) {
		this.identificationNumber = uniqueIdentificationNumber;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public int getNumberOfCopies() {
		return numberOfCopies;
	}


	public void setNumberOfCopies(int numberOfCopies) {
		this.numberOfCopies = numberOfCopies;
	}


	Exercise1(){
		
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	

class WrittenItem extends Exercise1{
	private String Author;
	
}
class Book extends WrittenItem{

	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
class JournalPaper extends WrittenItem{
	private int publishedYear;

	public JournalPaper() {
		super();
		// TODO Auto-generated constructor stub
	}
}
class MediaItem extends Exercise1{
	
}
class Video extends MediaItem{
	private String director;
	private String genre;
	private int year;

	public Video() {
		super();
		// TODO Auto-generated constructor stub
	}
}
class CD extends MediaItem{
	private String artist;
	private String genre;
}
	}
}


