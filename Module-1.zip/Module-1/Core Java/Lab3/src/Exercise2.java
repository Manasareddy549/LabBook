/*import java.util.Scanner;
public class Exercise2
{
    public static void main(String[] args) 
    {
        int n;
        String temp;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of strings:");
        n = sc.nextInt();
        String str[] = new String[n];
        Scanner sc1 = new Scanner(System.in);
        System.out.println("Enter all the names:");
        for(int i = 0; i < n; i++)
        {
            str[i] = sc1.nextLine();
        }
        for (int i = 0; i < n; i++) 
        {
            for (int j = i + 1; j < n; j++) 
            {
                if (str[i].compareTo(str[j])>0) 
                {
                    temp = str[i];
                    str[i] = str[j];
                    str[j] = temp;
                }
            }
        }
        System.out.print("Sorted Order is:");
        for (int i = 0; i < n - 1; i++) 
        {
            System.out.print(str[i] + ",");
        }
        System.out.print(str[n - 1]);
        
        for(int i=0;i<n;i++)
        {
		int l=str[i].length();
        System.out.println("length"+"="+l);
        int s1=l/2;
        System.out.println("half of string is"+"="+s1);
        String m=str[i].substring(0, s1);
        System.out.println(m);
        String m1=m.toUpperCase();
        System.out.println("string left half is"+ "="+m1);
        String n1=str[i].substring(s1, l);
        System.out.println(n1);
        String n2=n1.toLowerCase();
        System.out.println("string right half is"+"="+n2);
        }
    }
}


*/



import java.util.Scanner;

public class Exercise2 {
	String[] arrange(String a[]){
		int i,j;
		for(i=0;i<a.length;i++){
			for(j=i+1;j<a.length;j++){
				if(a[i].compareTo(a[j])>0){
					String temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		if(a.length%2==0){
			for(i=0;i<=((a.length)/2);i++){
				a[i]=a[i].toUpperCase();
			}
			for(i=((a.length)/2);i<a.length;i++){
				a[i]=a[i].toLowerCase();
			}
		}
		else{
			for(i=0;i<=(((a.length)/2)+1);i++){
				a[i]=a[i].toUpperCase();
			}
			for(i=(((a.length)/2)+1);i<a.length;i++){
				a[i]=a[i].toLowerCase();
			}
		}
		for(i=0;i<a.length;i++){
			System.out.println(a[i]);
		}
		return a;
		
	}

	public static void main(String[] args) {
		Exercise2 e = new Exercise2();
		@SuppressWarnings("resource")
		Scanner s = new Scanner(System.in);
		System.out.println("enter no.of elements in array");
		int n = s.nextInt();
		System.out.println("enter elements into array");
		String[] a = new String[n];// TODO Auto-generated method stub
		for (int k = 0; k < n; k++) {
			a[k] = s.next();
		}
		e.arrange(a);
	}

}
