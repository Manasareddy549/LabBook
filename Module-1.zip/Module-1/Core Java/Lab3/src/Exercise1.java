
import java.util.Scanner;

public class Exercise1 {
	// Get the second smallest element in the array
	static int getSecondSmallest(int n[]) {

		return n[1];
	}

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter array size ");

		int n = sc.nextInt();
		int[] a = new int[n];
		System.out.println("Enter the values");
		for (int i = 0; i < n; i++) {
			a[i] = sc.nextInt();
		}
		System.out.println("sorted array is:");
		for (int i = 0; i < a.length; i++) {
			for (int j = i + 1; j < a.length; j++) {
				if (a[i] > a[j]) {
					int temp;
					temp = a[i];
					a[i] = a[j];
					a[j] = temp;
				}
			}
		}
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i] + " ");
		}
		// System.out.println(a[1]+ "is the second element");
		System.out.println(Exercise1.getSecondSmallest(a) + " is the second smallest element");
	}
}
