
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.Set;
import java.util.Iterator;
import java.util.List;

@SuppressWarnings("unused")
public class Exercise1 {
List<Integer> getValues(HashMap<Integer, Integer> h1) {
		Collection<Integer> values = h1.values();
		ArrayList<Integer> listOfValues = new ArrayList<Integer>(values);
		Collections.sort(listOfValues);
		return listOfValues;

	}
    public static void main(String[] args) {
    	Exercise1 p = new Exercise1();
         HashMap<Integer,Integer>  hm = new HashMap<Integer,Integer> ();
 		System.out.println("number of entries to enter are:");				
 				Scanner sc = new Scanner(System.in);
 				Integer n=sc.nextInt();
 				System.out.println("enter hashmap entries");
 		for (int i = 0; i < n; i++) {
 			System.out.println("enter key");
 			int a = sc.nextInt();
System.out.println("enter values");
 			int b = sc.nextInt();
 			hm.put(a, b);
 			System.out.println(hm.put(a, b));
 		}

 		System.out.println(p.getValues(hm));
        
    }
}



