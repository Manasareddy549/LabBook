/*import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

public class Exercise3 {
	 public static HashMap getSquares(int[] array) {
		    HashMap<Integer, Integer> hm = new HashMap<Integer, Integer>();
		    		System.out.println("number of entries to enter are:");				
	 				Scanner sc = new Scanner(System.in);
	 				Integer n=sc.nextInt();
	 				System.out.println("enter hashmap entries");
	 		for (int i = 0; i < n; i++) {

	 			Integer a = sc.nextInt();

	 			Integer b = sc.nextInt();
	 			hm.put(a, b);
	 			System.out.println(hm.put(a, b));
	 		}

		    for (int n1: array) {
		      hm.put( n1, n1*n1);
		    }
		    return hm;
		  }
	public static void main(String[] args) {
		int array[] = new int[]{1,2,3,4,5,6,7,8,9};
		    HashMap<Integer, Integer> hm = getSquares(array);
		 
		    Iterator<Integer> it = hm.keySet().iterator();
		    while(it.hasNext()){
		    Integer key = it.next();
		      System.out.println(key + " : " + hm.get(key));
		    }
	}

}
*/




import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

public class Exercise3 {
	@SuppressWarnings({ "rawtypes", "unchecked" })
	Map getSquares(int[] c) {
		LinkedHashMap h = new LinkedHashMap();
		List<Integer> allfutures = new ArrayList();
		for (int i = 0; i < c.length; i++) {
			allfutures.add(c[i] * c[i]);
		}
		for (int i = 0; i < c.length; i++) {
			h.put(c[i], allfutures.get(i));

		}
		System.out.println(allfutures);
		Set set1 = h.entrySet();
		Iterator itr1 = set1.iterator();
		System.out.print("{");
		while (itr1.hasNext()) {
			Entry entry = (Entry) itr1.next();
			System.out.print("'" + entry.getKey() + "'" + ":");
			System.out.print(entry.getValue() + ",");
		}
		System.out.print("}");
		return h;

	}

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("enter no.of elements into string");
		int a = sc.nextInt();
		int[] c = new int[a];
		for (int i = 0; i < a; i++) {
			System.out.println("enter element");
			c[i] = sc.nextInt();
		}
		Exercise3 p = new Exercise3();
		p.getSquares(c);

	}

}












