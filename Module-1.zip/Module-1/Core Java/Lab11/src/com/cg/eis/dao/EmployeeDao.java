package com.cg.eis.dao;

import java.awt.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import com.cg.eis.bean.Employee;

public class EmployeeDao implements EmployeeDaoI{

	static ArrayList<Employee> l=new ArrayList<Employee>();
	public boolean addEmployee(Employee emp)
	{
		l.add(emp);
		
				
		if(emp!=null)
		{
			return false;
			
		}
		else
		{
			return true;
		}
		
		
	}
	public ArrayList<Employee> displayEmployee() {
		// TODO Auto-generated method stub
		return l;

	}
	
	
	public Employee particularEmployee(int eno3)
	{
		
		
		return l.get(eno3);

	
	}

	public HashMap<Integer, ArrayList<Comparable>> displayInsuranceScheme() {
		ArrayList list=new ArrayList();	
		HashMap hm=new HashMap();

		String insuranceScheme=null;
		 Iterator<Employee> itr = l.iterator(); 
		  
	        // Display element by element using Iterator 
	        while (itr.hasNext()) 
	        {
	        	
	            
	          Employee emp=  itr.next();
	        	Float s=emp.getSalary();
	        	String des=emp.getDesignation();
	        //	String str=(String) itr.next();
	        	if((s>5000&&s<2000)&&(des.equals("SystemAssociate")))
	        	{
	        		insuranceScheme="Scheme C";
                    list.add(s);
                    list.add(des);
                    list.add(insuranceScheme);
                    hm.put(1, list);
                 	        		
	        	}
	        	else if((s>=20000&&s<40000)&&(des.equals("programmer")))
	        			{
	        		insuranceScheme="Scheme B";
	        		 list.add(s);
	                    list.add(des);
	                    list.add(insuranceScheme);
	                   hm.put(2, list);
	                   		        		
	        			        			}
	        	else if((s>=40000)&&(des.equals("manager")))
    			{
	        		insuranceScheme="Scheme A";
	        		 list.add(s);
	                    list.add(des);
	                    list.add(insuranceScheme);
	                    hm.put(3, list);
	                   		        		
	        		    			}
	        	else if((s<5000)&&(des.equals("clerk")))
    			{
	        		insuranceScheme="No Scheme ";
	        		 list.add(s);
	                    list.add(des);
	                    list.add(insuranceScheme);
	                    hm.put(4, list);
	                   		        		
	        		    			}
    	
	        
	        }
	        
	         
				return hm;
				 
			
	//	return l;
		
	
	}
	
	

	
	
}
