package com.cg.eis.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.cg.eis.bean.Employee;
import com.cg.eis.dao.EmployeeDao;


public class EmployeeService implements EmployeeServiceI {

	static EmployeeDao dao=new EmployeeDao();

	public boolean addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return dao.addEmployee(emp);
	}

	public ArrayList<Employee> displayEmployee() {
		// TODO Auto-generated method stub
		return dao.displayEmployee();
	}
public HashMap displayInsuranceScheme() {
		// TODO Auto-generated method stub
	return dao.displayInsuranceScheme();
	}

	
	

	

	
	
}
