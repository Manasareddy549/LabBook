package com.cg.eis.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;

public class MainUi {
	static EmployeeService service=new EmployeeService();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	

		while(true)
		{
		
		System.out.println("1.add employee based on user input");
		System.out.println("2.display all details");
		System.out.println("3.find insurance scheme for employee details");
		
		
		
		Scanner scan= new Scanner(System.in);
		 int option = scan.nextInt();
		  
		switch (option)//input=1, flow-8
        {
	
	case 1:
			System.out.println("enter employee name");
		
		String name=scan.next();
        System.out.println("enter employee designation");
		
		String designation=scan.next();
		
		System.out.println("enter id of an employee");
		int id=scan.nextInt();
		
		System.out.println("enter salary of an employee");
		float salary=scan.nextFloat();
		Employee emp=new Employee(id,  name,salary,  designation);
		boolean result=service.addEmployee(emp);
		System.out.println(result);
		if(result==true)
		{
			System.out.println("insertion failed");
		}	
		else{
		System.out.println("inserted");
		}
       	break;

	case 2:
		System.out.println("show the details");
		ArrayList<Employee> emp1=service.displayEmployee();
		
		if(emp1!=null)
		{
			System.out.println(emp1);			
		}
		else
		{
			System.out.println("not found");
		}
		break;
		
	case 3:
		System.out.println("show the details to check designation and scheme");
		HashMap emp11=service.displayInsuranceScheme();
		
		if(emp11!=null)
		{
			System.out.println(emp11);			
		}
		else
		{
			System.out.println("not found");
		}
		break;
		
      
	
        }}

}
}