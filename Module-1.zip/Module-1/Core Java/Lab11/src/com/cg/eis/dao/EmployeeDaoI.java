package com.cg.eis.dao;

import java.util.ArrayList;
import java.util.HashMap;

import com.cg.eis.bean.Employee;

public interface EmployeeDaoI {

	
	public boolean addEmployee(Employee emp) ;
	
	public ArrayList<Employee> displayEmployee();
	public HashMap displayInsuranceScheme();
	//public Employee particularEmployee(int eno3);
}
