import java.util.Scanner;

@FunctionalInterface
interface formatString{
	String space(String str);
}

public class Exercise2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("string is:");
String s=sc.next();
formatString f=(s1)->{return s1.replace("", " ");};
System.out.println(f.space(s));
	}

}
