import java.util.Scanner;

@FunctionalInterface
interface powerOfFunction{
	 double power(int  x,int y);
	
}




public class Exercise1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter x and y values");
		int x=sc.nextInt();
		int y=sc.nextInt();
powerOfFunction f=(a,b)->(Math.pow(x,y));

System.out.println(f.power(x,y));
	}

}
