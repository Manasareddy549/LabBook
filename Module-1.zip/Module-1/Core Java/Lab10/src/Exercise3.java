import java.util.Scanner;
import java.util.function.BiPredicate;
import java.util.function.Predicate;
@FunctionalInterface
interface accept{
		boolean check(String s, String s1);
	
}
public class Exercise3 {

	public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
System.out.println("enter username");
String s=sc.next();
System.out.println("enter password");
String s1=sc.next();
String username="capgemini";
String password="anurag123";
accept f=(t,u)->{
	if(username.equals(s)&&password.equals(s1))

return true;
	else
		return false;};

	}
}