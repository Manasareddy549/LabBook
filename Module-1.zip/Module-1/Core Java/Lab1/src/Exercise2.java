import java.util.Scanner;

public class Exercise2 {
	//Calculate the difference 
	static int calculateDifference(int n)
	{
		int Sum;
		int s1,s2; 
	    	    s1= (n * (n + 1) * (2 * n + 1)) / 6; 
	      
	    	    s2= (n * (n + 1)) / 2; 
	  
	    s2 = s2 * s2; 
	    Sum= (s2 - s1); 
		return Sum;
		
	}
	public static void main(String[] args) {
 
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int n = sc.nextInt();
		int result = Exercise2.calculateDifference(n);
		System.out.println(Exercise2.calculateDifference(n));
	      

	}

}
