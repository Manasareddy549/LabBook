import java.util.Scanner;

public class Exercise4 {
	//Checks if the entered number is a power of two or not 
	public static boolean checkNumber(int n)
	{
		
		if(n==0)
		{
			return false;
		}
		while(n!=1)
		{
			if(n%2!=0)
			{
				return false;
			//n=n/2;
			}

			else
				
			break;
		
		}
			return true;
	}
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int n = sc.nextInt();
		boolean result = Exercise4.checkNumber(n);
		System.out.println(Exercise4.checkNumber(n));
		}	
}

