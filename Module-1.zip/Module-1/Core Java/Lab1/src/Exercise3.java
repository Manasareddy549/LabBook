import java.util.Scanner;
//Check if a number is an increasing number 
class Exercise3 {
	public static boolean checkNumber(int num)// 12345
	{
		int currentDigit = num % 10;// 5
		num = num / 10;// 1234
		while (num > 0) {
			
			if (currentDigit <= num % 10) // 3 <=4
			{
				return false;

			}
			else {

				break;
			}
		}
		return true;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int n = sc.nextInt();
		boolean result = Exercise3.checkNumber(n);
		System.out.println(Exercise3.checkNumber(n));
	}
}
