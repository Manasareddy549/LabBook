public class Vowel{
	static boolean alterString(char ch)
	{
		if(ch!='a'&&ch!='e'&&ch!='i'&&ch!='o'&&ch!='u')
		return false;
		else
			return true;
	}

	
	  static String Consonants(char[] str)  
	    { 
	      for(int i=0;i<str.length;i++){  		  
		  if(!alterString(str[i]))
                  str[i] = (char) (str[i] + 1); 
                  if (alterString(str[i]))  
                  { 
                	 // System.out.println(str[i]);
                  }
	    
	      }
          
	      
		return String.valueOf(str);
          }

	public static void main(String[] args) {
		String s="java";
		System.out.println(Consonants(s.toCharArray()));
		
		
		
	}

}
