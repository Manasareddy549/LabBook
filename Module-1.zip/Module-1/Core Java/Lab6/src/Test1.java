//for deserialization
import java.io.*;
public class Test1 {
public static void main(String args[])throws IOException , ClassNotFoundException{
		FileInputStream fis=new FileInputStream("anurag123.txt");
	ObjectInputStream ois=new ObjectInputStream(fis);
	Emp e2=(Emp) ois.readObject();
	System.out.println(e2.getAtmpin());
	System.out.println(e2.getEmpid());
	System.out.println(e2.getEmpname());
}
}
