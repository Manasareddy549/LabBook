
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
public class TestFile {
public static void main(String args[])throws IOException {
	
	
	Emp e=new Emp();
	e.setAtmpin(1234);
	e.setEmpid(3);
	e.setEmpname("manasa");
	FileOutputStream fos=new FileOutputStream("anurag123.txt");
	ObjectOutputStream oos=new ObjectOutputStream(fos);
	System.out.println("done");
}
}