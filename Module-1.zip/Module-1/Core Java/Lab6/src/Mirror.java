public class Mirror{
	
	//Generate the mirror image of a String and add it to the existing string. 
	static String getImage(String string)
	{
		StringBuffer sbf=new StringBuffer("EARTH");
		System.out.println(sbf);
		StringBuffer t= sbf.reverse();
		System.out.println(t);
		StringBuffer sbf1=new StringBuffer("EARTH"); 
		System.out.println("string reverse is" +  sbf1.append('|') + t);

		return string;
	}

	public static void main(String[] args) {		

		Mirror m=new Mirror();
		System.out.println(m.getImage(" "));
		
	}



}
