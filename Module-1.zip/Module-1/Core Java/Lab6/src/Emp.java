
import java.io.Serializable;
public class Emp implements Serializable{
	private int empid;
	private String empname;
	private int atmpin;
	//transient private int atmpin;//to hide or secure the data
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public int getAtmpin() {
		return atmpin;
	}
	public void setAtmpin(int atmpin) {
		this.atmpin = atmpin;
	}
}


