/*import java.util.Scanner;

public class Exercise10 {

	static boolean check()
	{
		System.out.println("enter username");
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		//		for(int i=0;i < s.length();i++) {
	      //  char ch = s.charAt(i);
	        //System.out.println(ch);
	        
		int ch = 0;
		int sum=Integer.parseInt(String.valueOf(ch)); 
	      
	       // if(s.substring(ch)<=8)
	        {
	            boolean result= true;
	        }
	       // else if(s.endsWith("_job"))
	        {
	        	boolean result=true;
	        }
	        boolean name=false;
			boolean number=false;
			if(number && name)
	            return true;
		
	
	return false;
	}

	public static void main(String[] args) {
		//System.out.println("EndsWith character : " + s.endsWith("_job"));
	//	if((boolean) (s.endsWith("_job")?"valid":"invalid " != null))

System.out.println(Exercise10.check());
	}

}

*/








import java.util.Scanner;

public class Exercise10 {
	Boolean validate(String s) {
		s.contains("_job");
		int a = s.lastIndexOf("_job");
		String s1 = "";
		for (int i = a; i < s.length(); i++) {
			s1 += s.charAt(i);
		}
		if (s.length() > 12 && s1.contains("_job")) {
			return true;

		} else
			return false;
	}

	public static void main(String[] args) {
		System.out.println("Username should always end with _job\n"
				+ "there should be at least minimum of 8 characters to the left of _job");
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		Exercise10 p = new Exercise10();
		System.out.println(p.validate(s));
	}

}

