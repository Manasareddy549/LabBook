import java.util.*;
import java.io.*;

public class Exercise2 {
	public static void main(String args[]) throws IOException {
		int list = 1;
		char ch;
		Scanner sc = new Scanner(System.in);
		System.out.print("\nEnter File name: ");
		String str = sc.next();
		FileInputStream fis = new FileInputStream(str);
		System.out.println("\nContents of the file are");
		int n = fis.available();
		  System.out.print(list+": ");
          for(int i=0;i<n;i++)
          {
                      ch=(char) fis.read();
                      System.out.print(ch);
                      if(ch=='\n')
                      {
                                  System.out.print(++list+": ");
                                 
                      }      

	}
}
}





