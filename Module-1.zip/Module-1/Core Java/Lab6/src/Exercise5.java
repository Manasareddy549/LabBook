/*import java.util.Scanner;

public class Exercise5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("enter size");
int size=sc.nextInt();
System.out.println(size);
System.out.println("enter number");
String n=sc.next();
System.out.println(n);

String str1 = null;
char ch2 = 0;
for (int i = 0; i < size-1; i++) {
  char ch = n.charAt(i);  
   
    int di1=Integer.parseInt(String.valueOf(ch));  
     ch2 = n.charAt(i + 1);
       int di2=Integer.parseInt(String.valueOf(ch2));
    int diff = Math.abs(di1 - di2);
    System.out.println(diff);

StringBuffer str=new StringBuffer(diff);

 str1= str.toString();

}
System.out.print(str1+ " "+ch2);
	}
}


*/





import java.util.Scanner;

public class Exercise5 {
	int modifyNumber(int number1) {
		String s = Integer.toString(number1);
		int j = 0;
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < s.length() - 1; i++) {
			j = Math.abs(s.charAt(i) - s.charAt(i + 1));

			sb.append(j);

		}
		sb.append(s.charAt((int) s.length() - 1));
		String s2 = sb.toString();
		int b = Integer.parseInt(s2);
		number1 = b;

		return number1;
	}

	public static void main(String[] args) {
		System.out.println("Enter the number");
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		Exercise5 p = new Exercise5();
		System.out.println(p.modifyNumber(a));
	}

}
