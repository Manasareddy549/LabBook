import java.util.Arrays;
import java.util.Scanner;

public class Exercise8 {

	static boolean isPositiveString(String str)
	{ 
		System.out.println("enter size");
		Scanner sc=new Scanner(System.in);
		int size=sc.nextInt();
		System.out.println("enter any string");
		Scanner sc1=new Scanner(System.in);

		String s=sc1.nextLine();
		int n=s.length();
		System.out.println(n);
		char ch[]=new char [size];
		for(int i=0;i<size;i++)
		{
			ch[i]=s.charAt(i);
		}
		Arrays.sort(ch);		
		for (int i = 0; i < n; i++)  
            if (ch[i] != s.charAt(i))   
    
		return false;
		return true;
		
	}
	
	public static void main(String[] args) {
		 String s = "ant";
		if (isPositiveString(s))  
	           System.out.println("Yes");  
	        else
	            System.out.println("No");  		
	}

}
