package com.cg.eis.service;

public interface EmployeeServicel {
	int addEmployee(int empId, String empDesg, String empName, float empSal);

}
